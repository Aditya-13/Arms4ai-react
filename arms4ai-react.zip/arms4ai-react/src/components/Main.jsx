import React from 'react'
import { AiOutlineSearch } from 'react-icons/ai'
import { FiUpload } from 'react-icons/fi'
import { BsCircle } from 'react-icons/bs'
import { HiOutlineMinus } from 'react-icons/hi'
import { BsTextarea } from 'react-icons/bs'
import { SiGraphql } from 'react-icons/si'
import { BsXDiamond } from 'react-icons/bs'
import { ImStack } from 'react-icons/im'
import { BiUpArrowAlt } from 'react-icons/bi'
import { AiOutlineDown } from 'react-icons/ai'
import { CiCalendar } from 'react-icons/ci'

const Main = () => {
    const arr = ['Sucrose' , 'Harvest Date' , 'Crop Water Stress' , 'Crop Yield' , 'Barren Land' , 'Trees' , 'Forestry' , 'Flood' , 'Land Mass']
  return (
    <div>
        <div className='h-[869px] w-[420px] bg-[#1A2737] rounded-[40px] mx-6 my-[38px] px-[42px] py-[36px]'>
            <div className='flex items-center justify-between text-white'>
                <h1 className='font-semibold text-xl'>Area Of Interest</h1>
                <button className='px-3 py-[10px] bg-opacity-[8%] rounded-[100px] bg-white'>Free trial</button>
            </div>

            <div className='mt-[25px]'>
                <input type="text" placeholder='Patna' className='px-4 w-[242px] py-[7px] text-white text-sm font-normal rounded-[1000px]'/>
                <button className='p-[10px] ml-3 bg-white rounded-[1000px]'><AiOutlineSearch className='fill-[#4CB963] h-3 w-3' /></button>
                <button className='p-[10px] ml-2 bg-[#1A2737] upload-bg'><FiUpload className='fill-white text-white h-3 w-3' /></button>
            </div>

            <div className='mt-[30px]'>
            <h1 className='font-medium text-base text-white'>Draw boundary</h1>
            <div className='mt-[22px] flex items-center text-white justify-between'>
                <div className='flex items-center'>
                    <BsCircle className='fill-[#D2D2D2] h-[18px] w-[18px]'/>
                    <HiOutlineMinus className='ml-[15px] opacity-20 rotate-90 h-[18px]' />
                    <BsTextarea  className='fill-[#D2D2D2] ml-[15px]'/>
                    <HiOutlineMinus className='ml-[15px] opacity-20 rotate-90 h-[18px]' />
                    <SiGraphql className='fill-[#D2D2D2] ml-[15px]'/>
                    <HiOutlineMinus className='ml-[15px] opacity-20 rotate-90 h-[18px]' />
                    <button className='p-2 bg-[#2C3847] rounded-full ml-2'>
                    <BsXDiamond className='fill-[#D2D2D2]'/>
                    </button>
                </div>
                <div>
                    <h1>00 Sq. Ft</h1>
                </div>
            </div>
            </div>

            <div>
            <div className='mt-14 flex items-center text-white'>
                <ImStack />
                <h1 className='ml-3 text-base font-normal opacity-[65%]'>Parameters</h1>
            </div>

            <div className='mt-[23px] pl-[23px] pt-[13px] pb-6 parameter-div-bg'>
                <div className='flex items-center justify-between'>
                <input type="text" placeholder='Select Parameters' className='text-white opacity-[48%] font-normal text-sm bg-transparent outline-none' />
                <button className='p-4 bg-[#3F4A57] rounded-full mr-1'>
                    <BiUpArrowAlt className='text-white'/>
                </button>
                </div>
                <div className='mt-[25px] pb-6 overflow-x-scroll overflow-param h-[224px]'>
                    {
                        arr.map((el, i) => <span id={i} className={`block ${i == 0 ? '' : 'mt-[10px]'} text-white font-normal text-xs`}>{el}</span>)
                    }
                </div>
            </div>

            <div className='flex items-center text-white mt-10'>
                <CiCalendar className='h-5 w-5 fill-white'/>
                <h2 className='opacity-[65%] ml-3 font-normal text-base'>Date</h2>
            </div>

            <div className='mt-4 flex items-center text-white'>
                <span className='mt-1 text-xs font-normal'>From</span>
                <input type="date" className='date-input ml-2 bg-transparent outline-none' min="2018-01-01" max="2023-12-31" />
                <AiOutlineDown className='ml-3 mt-1 p-[2px]'/>

                <span className='mt-1 ml-[43px] text-xs font-normal'>To</span>
                <input type="date" className='date-input ml-2 bg-transparent outline-none' min="2018-01-01" max="2023-12-31" />
                <AiOutlineDown className='ml-3 mt-1 p-[2px]'/>
            </div>
            
            <div className='mt-4'>
                <button className='px-[140px] text-sm font-medium py-5 text-white bg-[#4CB963] rounded-full'>Continue</button>
            </div>
            </div>
        </div>
    </div>
  )
}

export default Main