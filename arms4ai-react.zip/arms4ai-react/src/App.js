import './App.css';
import Navbar from './components/Navbar';
import Main from './components/Main';
import Zoom from './components/Zoom';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';

function App() {
  const position = [51.505, -0.09]
  return (
    <div className='overflow-hidden' style={{width: '100%', height: '100%', display: 'grid', gridTemplateRows: '1fr', gridTemplateColumns: '1fr' }}>
    <div style={{ gridRow: '1 / span 1', gridColumn: '1 / span 1', position: 'relative', height: '100vh' }}>
      <MapContainer center={position} zoom={13} scrollWheelZoom={false} style={{ height: 'fit-content', width: '100%' }}>
    <TileLayer
      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
    <Marker position={position}>
      <Popup>
        A pretty CSS3 popup. <br /> Easily customizable.
      </Popup>
    </Marker>
  </MapContainer>
      </div>

      <div
      className='base'
       style={{ gridRow: '1 / span 1', gridColumn: '1 / span 1', position: 'relative' }}>
      <Navbar />
      <Main />
      <Zoom />
    </div>
        </div>
  );
}

export default App;
