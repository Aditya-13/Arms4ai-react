import React from 'react'
import { AiOutlinePlus , AiOutlineMinus } from 'react-icons/ai'

const Zoom = () => {
  return (
    <>
    <div className='flex items-center justify-center'>
        <button className='p-5 bg-[#1A2737] rounded-full text-white'>
            <AiOutlinePlus />
        </button>

        <button className='p-5 ml-[14px] bg-[#1A2737] rounded-full text-white'>
            <AiOutlineMinus />
        </button>
    </div>

    <div className='flex items-center justify-center lat-long-bg'>
        <h1 className='text-xs font-medium text-white'>Lat: 12:98765 , Lng : 76:94345  |  100 m</h1>
    </div>
    </>
  )
}

export default Zoom