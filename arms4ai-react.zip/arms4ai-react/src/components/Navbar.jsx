import React from 'react'
import { AiOutlineFileAdd } from 'react-icons/ai'
import { BsBoxes } from 'react-icons/bs'
import { TfiBook } from 'react-icons/tfi'
import { RxHamburgerMenu } from 'react-icons/rx'
import { TbOlympics } from 'react-icons/tb'

const Navbar = () => {
  return (
    <>
    <div className='pt-12 px-6 flex justify-between items-center'>
      <div>    
      <button className='text-xl font-medium text-white p-4 rounded-[1000px] bg-[#4CB963]'>JD</button>
      <button className='ml-12 py-[18px] px-[22px] bg-[#1A2737] rounded-[100px]'>
        <div className='flex items-center'>
      <AiOutlineFileAdd className='fill-white text-xl mr-[13px]'/>
        <span className='text-[#c4c4c4] font-medium'>New Project</span>
        </div>
      </button>

      <button className='ml-3 py-[18px] px-[22px] bg-[#1A2737] rounded-[100px]'>
        <div className='flex items-center'>
      <AiOutlineFileAdd className='fill-white text-xl mr-[13px]'/>
        <span className='text-[#c4c4c4] font-medium'>Demo</span>
        </div>
      </button>
      </div>
      <div>
        <button className='p-[18px] rounded-[1000px] bg-[#1A2737]'><BsBoxes className='fill-white text-xl' /></button>
        <button className='p-[18px] rounded-[1000px] ml-2 bg-[#1A2737]'><TfiBook className='fill-white text-xl' /></button>
        <button className='ml-4 py-[18px] px-[22px] bg-[#1A2737] rounded-[100px]'>
        <div className='flex items-center'>
      <TbOlympics className='fill-white text-xl mr-[13px]'/>
        <span className='text-[#c4c4c4] font-medium'>Agri Ai</span>
      <RxHamburgerMenu className='fill-white text-xl ml-5 text-white'/>
        </div>
      </button>
      </div>
    </div>
    </>
  )
}

export default Navbar